#!/bin/sh
set -eu
if ! command -v arm-none-eabi-gcc >/dev/null 2>&1; then
  echo "Toolchain manquante: installe devkitARM/binutils-arm-none-eabi puis relance." >&2
  exit 1
fi
make -j"${JOBS:-2}" modern
echo "ROM créée: pokeemerald_modern.gba"
