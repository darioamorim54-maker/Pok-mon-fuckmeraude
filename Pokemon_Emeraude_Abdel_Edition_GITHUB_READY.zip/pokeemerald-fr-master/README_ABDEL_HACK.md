# Pokémon Émeraude — Abdel Edition

Refonte humoristique du projet pokeemerald-fr.

- Noms officiels des Pokémon conservés.
- Dialogues des scripts de cartes retravaillés avec humour absurde.
- MACH BIKE affichée comme GT86 et ACRO BIKE comme GT86 RALLY.
- Sprites de véhicule remplacés par des sprites pixel-art inspirés de la Toyota GT86.
- Aucune promesse de ROM précompilée : le dépôt nécessite la toolchain GBA du projet.
