# Pokémon Émeraude Abdel Edition — compilation cloud depuis un téléphone

## Méthode GitHub Actions (recommandée)

1. Crée un compte GitHub puis un dépôt **privé**.
2. Dans le dépôt : **Add file → Upload files**.
3. Envoie le contenu de ce dossier (pas seulement le ZIP).
4. Ouvre l'onglet **Actions**.
5. Sélectionne **Build Pokémon Émeraude Abdel Edition**.
6. Appuie sur **Run workflow**.
7. Attends que le voyant passe au vert.
8. Ouvre l'exécution terminée, puis la section **Artifacts**.
9. Télécharge `Pokemon-Emeraude-Abdel-Edition-GBA.zip`.
10. Décompresse-le sur ton téléphone : tu y trouveras `pokeemerald_modern.gba`.

Le workflow installe automatiquement la toolchain ARM sur une machine GitHub et compile la ROM.

## Important

Cette compilation produit une ROM issue du projet de décompilation fourni, avec les modifications Abdel Edition. Elle n'est pas un patch binaire direct de la ROM française originale.
