const u8 gGiftRibbonDescriptionPart1_2003RegionalTourney[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart2_Champion[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_2003NationalTourney[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart1_2003GlobalCup[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart2_RunnerUp[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart2_Semifinalist[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart1_2004RegionalTourney[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_2004NationalTourney[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart1_2004GlobalCup[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart1_2005RegionalTourney[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart1_2005NationalTourney[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart1_2005GlobalCup[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_PokemonBattleCup[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart2_Participation[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart1_PokemonLeague[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart1_AdvanceCup[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart1_PokemonTournament[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart2_Participation2[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart1_PokemonEvent[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart1_PokemonFestival[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart1_DifficultyClearing[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart2_Commemorative[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_ClearingAllChallenges[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart2_ClearingAllChallenges[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart1_100StraightWin[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart1_DarknessTower[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart1_RedTower[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_BlackironTower[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart1_FinalTower[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart1_LegendMaking[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart1_PokemonCenterTokyo[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart1_PokemonCenterOsaka[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_PokemonCenterNagoya[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart1_PokemonCenterNY[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart1_SummerHolidays[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart2_EmptyString[] = _("");
const u8 gGiftRibbonDescriptionPart1_WinterHolidays[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_SpringHolidays[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart1_Evergreen[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart1_SpecialHoliday[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart1_HardWorker[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart1_LotsOfFriends[] = _("Un truc utile, bizarre et parfaitement Pokémon.");
const u8 gGiftRibbonDescriptionPart1_FullOfEnergy[] = _("Ça fait quelque chose. C'est déjà bien.");
const u8 gGiftRibbonDescriptionPart1_LovedPokemon[] = _("Une merveille de technologie douteuse.");
const u8 gGiftRibbonDescriptionPart2_LovedPokemon[] = _("Abdel recommande : ne pas poser de questions.");
const u8 gGiftRibbonDescriptionPart1_LoveForPokemon[] = _("Une description très sérieuse. Enfin, presque.");
const u8 gGiftRibbonDescriptionPart2_LoveForPokemon[] = _("Un truc utile, bizarre et parfaitement Pokémon.");

const u8 *const gGiftRibbonDescriptionPointers[MAX_GIFT_RIBBON][2] =
{
    {gGiftRibbonDescriptionPart1_2003RegionalTourney,   gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2003NationalTourney,   gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2003GlobalCup,         gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2003RegionalTourney,   gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2003NationalTourney,   gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2003GlobalCup,         gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2003RegionalTourney,   gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2003NationalTourney,   gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2003GlobalCup,         gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2004RegionalTourney,   gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2004NationalTourney,   gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2004GlobalCup,         gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2004RegionalTourney,   gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2004NationalTourney,   gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2004GlobalCup,         gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2004RegionalTourney,   gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2004NationalTourney,   gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2004GlobalCup,         gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2005RegionalTourney,   gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2005NationalTourney,   gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2005GlobalCup,         gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_2005RegionalTourney,   gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2005NationalTourney,   gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2005GlobalCup,         gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_2005RegionalTourney,   gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2005NationalTourney,   gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_2005GlobalCup,         gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_PokemonBattleCup,      gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_PokemonBattleCup,      gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_PokemonBattleCup,      gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_PokemonBattleCup,      gGiftRibbonDescriptionPart2_Participation},
    {gGiftRibbonDescriptionPart1_PokemonLeague,         gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_PokemonLeague,         gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_PokemonLeague,         gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_PokemonLeague,         gGiftRibbonDescriptionPart2_Participation},
    {gGiftRibbonDescriptionPart1_AdvanceCup,            gGiftRibbonDescriptionPart2_Champion},
    {gGiftRibbonDescriptionPart1_AdvanceCup,            gGiftRibbonDescriptionPart2_RunnerUp},
    {gGiftRibbonDescriptionPart1_AdvanceCup,            gGiftRibbonDescriptionPart2_Semifinalist},
    {gGiftRibbonDescriptionPart1_AdvanceCup,            gGiftRibbonDescriptionPart2_Participation},
    {gGiftRibbonDescriptionPart1_PokemonTournament,     gGiftRibbonDescriptionPart2_Participation2},
    {gGiftRibbonDescriptionPart1_PokemonEvent,          gGiftRibbonDescriptionPart2_Participation2},
    {gGiftRibbonDescriptionPart1_PokemonFestival,       gGiftRibbonDescriptionPart2_Participation2},
    {gGiftRibbonDescriptionPart1_DifficultyClearing,    gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_ClearingAllChallenges, gGiftRibbonDescriptionPart2_ClearingAllChallenges},
    {gGiftRibbonDescriptionPart1_100StraightWin,        gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_DarknessTower,         gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_RedTower,              gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_BlackironTower,        gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_FinalTower,            gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_LegendMaking,          gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_PokemonCenterTokyo,    gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_PokemonCenterOsaka,    gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_PokemonCenterNagoya,   gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_PokemonCenterNY,       gGiftRibbonDescriptionPart2_Commemorative},
    {gGiftRibbonDescriptionPart1_SummerHolidays,        gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_WinterHolidays,        gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_SpringHolidays,        gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_Evergreen,             gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_SpecialHoliday,        gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_HardWorker,            gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_LotsOfFriends,         gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_FullOfEnergy,          gGiftRibbonDescriptionPart2_EmptyString},
    {gGiftRibbonDescriptionPart1_LovedPokemon,          gGiftRibbonDescriptionPart2_LovedPokemon},
    {gGiftRibbonDescriptionPart1_LoveForPokemon,        gGiftRibbonDescriptionPart2_LoveForPokemon}
};
