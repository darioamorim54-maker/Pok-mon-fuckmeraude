static const u8 sDummyDesc[] = _(
    "?????");

// Pokeballs
static const u8 sMasterBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sUltraBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sGreatBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPokeBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSafariBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sNetBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sDiveBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sNestBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRepeatBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sTimerBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLuxuryBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPremierBallDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

// Medicine
static const u8 sPotionDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sAntidoteDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBurnHealDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sIceHealDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sAwakeningDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sParalyzeHealDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFullRestoreDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMaxPotionDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHyperPotionDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSuperPotionDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sFullHealDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sReviveDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMaxReviveDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sFreshWaterDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSodaPopDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLemonadeDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMoomooMilkDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sEnergyPowderDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sEnergyRootDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHealPowderDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRevivalHerbDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sEtherDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMaxEtherDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sElixirDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMaxElixirDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sLavaCookieDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBlueFluteDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sYellowFluteDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRedFluteDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBlackFluteDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sWhiteFluteDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sBerryJuiceDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSacredAshDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

// Collectibles
static const u8 sShoalSaltDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sShoalShellDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRedShardDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBlueShardDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sYellowShardDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sGreenShardDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

// Vitamins
static const u8 sHPUpDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sProteinDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sIronDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sCarbosDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sCalciumDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRareCandyDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sPPUpDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sZincDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sPPMaxDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

// Battle items
static const u8 sGuardSpecDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sDireHitDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sXAttackDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sXDefendDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sXSpeedDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sXAccuracyDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sXSpecialDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPokeDollDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sFluffyTailDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

// Field items
static const u8 sSuperRepelDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMaxRepelDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sEscapeRopeDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sRepelDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

// Evolution stones
static const u8 sSunStoneDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sMoonStoneDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sFireStoneDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sThunderStoneDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sWaterStoneDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sLeafStoneDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

// Valuable items
static const u8 sTinyMushroomDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sBigMushroomDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sPearlDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sBigPearlDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sStardustDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sStarPieceDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sNuggetDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sHeartScaleDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

// Mail
static const u8 sOrangeMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sHarborMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sGlitterMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMechMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sWoodMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sWaveMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBeadMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sShadowMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTropicMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sDreamMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sFabMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRetroMailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

// Berries
static const u8 sCheriBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sChestoBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPechaBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRawstBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sAspearBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLeppaBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sOranBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPersimBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLumBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSitrusBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sFigyBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWikiBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMagoBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sAguavBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sIapapaBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRazzBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBlukBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sNanabBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWepearBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPinapBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPomegBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sKelpsyBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sQualotBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHondewBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sGrepaBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sTamatoBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sCornnBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMagostBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRabutaBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sNomelBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSpelonBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPamtreBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWatmelBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sDurinBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBelueBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLiechiBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sGanlonBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSalacBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPetayaBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sApicotBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLansatBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sStarfBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sEnigmaBerryDesc[] = _(
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

// Hold items
static const u8 sBrightPowderDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sWhiteHerbDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMachoBraceDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sExpShareDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sQuickClawDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSootheBellDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMentalHerbDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sChoiceBandDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sKingsRockDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSilverPowderDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sAmuletCoinDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sCleanseTagDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSoulDewDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDeepSeaToothDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDeepSeaScaleDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSmokeBallDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sEverstoneDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFocusBandDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sLuckyEggDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sScopeLensDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMetalCoatDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sLeftoversDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDragonScaleDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sLightBallDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSoftSandDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sHardStoneDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMiracleSeedDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBlackGlassesDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBlackBeltDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMagnetDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMysticWaterDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSharpBeakDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPoisonBarbDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sNeverMeltIceDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSpellTagDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTwistedSpoonDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sCharcoalDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDragonFangDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSilkScarfDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sUpGradeDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sShellBellDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSeaIncenseDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLaxIncenseDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sLuckyPunchDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMetalPowderDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sThickClubDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sStickDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRedScarfDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBlueScarfDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPinkScarfDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sGreenScarfDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sYellowScarfDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

// Key items
static const u8 sMachBikeDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sCoinCaseDesc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sItemfinderDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sOldRodDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sGoodRodDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSuperRodDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSSTicketDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sContestPassDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sWailmerPailDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sDevonGoodsDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSootSackDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBasementKeyDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sAcroBikeDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sPokeblockCaseDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque. {POKEBLOCK}\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sLetterDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sEonTicketDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRedOrbDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBlueOrbDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sScannerDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sGoGogglesDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMeteoriteDesc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRoom1KeyDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRoom2KeyDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRoom4KeyDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRoom6KeyDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sStorageKeyDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRootFossilDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sClawFossilDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sDevonScopeDesc[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

// TMs/HMs
static const u8 sTM01Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM02Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM03Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM04Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM05Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM06Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM07Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM08Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM09Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM10Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM11Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM12Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM13Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM14Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM15Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM16Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM17Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM18Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM19Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM20Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM21Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM22Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM23Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM24Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM25Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM26Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM27Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM28Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM29Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM30Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM31Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM32Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM33Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM34Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM35Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM36Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM37Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM38Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM39Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM40Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM41Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM42Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM43Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM44Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM45Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM46Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM47Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM48Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM49Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTM50Desc[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");


static const u8 sHM01Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHM02Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHM03Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHM04Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHM05Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHM06Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHM07Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHM08Desc[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

// FireRed/LeafGreen key items
static const u8 sOaksParcelDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPokeFluteDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSecretKeyDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBikeVoucherDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sGoldTeethDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sOldAmberDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sCardKeyDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sLiftKeyDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sHelixFossilDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDomeFossilDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSilphScopeDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBicycleDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTownMapDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sVSSeekerDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFameCheckerDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTMCaseDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBerryPouchDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTeachyTVDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTriPassDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sRainbowPassDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTeaDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMysticTicketDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sAuroraTicketDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPowderJarDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sRubyDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSapphireDesc[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

// Emerald-specific key items
static const u8 sMagmaEmblemDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sOldSeaMapDesc[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");
