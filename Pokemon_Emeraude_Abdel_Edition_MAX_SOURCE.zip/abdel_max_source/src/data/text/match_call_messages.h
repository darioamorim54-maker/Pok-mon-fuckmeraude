const u8 gText_MatchCallAromaLady_Rose_Strategy[] = _("Becalm fighting emotions.");
const u8 gText_MatchCallAromaLady_Rose_Pokemon[] = _("Fragrant GRASS POKéMON.");
const u8 gText_MatchCallAromaLady_Rose_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallAromaLady_Rose_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallRuinManiac_Andres_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallRuinManiac_Andres_Pokemon[] = _("Ruin-exploration partners.");
const u8 gText_MatchCallRuinManiac_Andres_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallRuinManiac_Andres_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallRuinManiac_Dusty_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallRuinManiac_Dusty_Pokemon[] = _("Craggy ROCK POKéMON.");
const u8 gText_MatchCallRuinManiac_Dusty_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallRuinManiac_Dusty_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallTuber_Lola_Strategy[] = _("I'm going to try hard!");
const u8 gText_MatchCallTuber_Lola_Pokemon[] = _("Good swimmer POKéMON.");
const u8 gText_MatchCallTuber_Lola_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTuber_Lola_Intro2[] = _("using an inner tube.");

const u8 gText_MatchCallTuber_Ricky_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTuber_Ricky_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTuber_Ricky_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTuber_Ricky_Intro2[] = _("I just like my inner tube.");

const u8 gText_MatchCallSisAndBro_LilaAndRoy_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSisAndBro_LilaAndRoy_Pokemon[] = _("We like friendly POKéMON.");
const u8 gText_MatchCallSisAndBro_LilaAndRoy_Intro1[] = _("We enjoy POKéMON together");
const u8 gText_MatchCallSisAndBro_LilaAndRoy_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallCooltrainer_Cristin_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallCooltrainer_Cristin_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallCooltrainer_Cristin_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallCooltrainer_Cristin_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallCooltrainer_Brooke_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallCooltrainer_Brooke_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallCooltrainer_Brooke_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallCooltrainer_Brooke_Intro2[] = _("POKéMON CHAMPION.");

const u8 gText_MatchCallCooltrainer_Wilton_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallCooltrainer_Wilton_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallCooltrainer_Wilton_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallCooltrainer_Wilton_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallHexManiac_Valerie_Strategy[] = _("Slow, steady suffering.");
const u8 gText_MatchCallHexManiac_Valerie_Pokemon[] = _("Scary to meet at night.");
const u8 gText_MatchCallHexManiac_Valerie_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallHexManiac_Valerie_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallLady_Cindy_Strategy[] = _("Anything to win.");
const u8 gText_MatchCallLady_Cindy_Pokemon[] = _("Gorgeous type!");
const u8 gText_MatchCallLady_Cindy_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallLady_Cindy_Intro2[] = _("my POKéMON at home.");

const u8 gText_MatchCallBeauty_Thalia_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallBeauty_Thalia_Pokemon[] = _("Mature WATER type.");
const u8 gText_MatchCallBeauty_Thalia_Intro1[] = _("I dream of cruising around");
const u8 gText_MatchCallBeauty_Thalia_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallBeauty_Jessica_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallBeauty_Jessica_Pokemon[] = _("Cute, of course.");
const u8 gText_MatchCallBeauty_Jessica_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallBeauty_Jessica_Intro2[] = _("I seem to end up there.");

const u8 gText_MatchCallRichBoy_Winston_Strategy[] = _("Strategy? Who needs it?");
const u8 gText_MatchCallRichBoy_Winston_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallRichBoy_Winston_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallRichBoy_Winston_Intro2[] = _("custom POKéMON bed.");

const u8 gText_MatchCallPokeManiac_Steve_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPokeManiac_Steve_Pokemon[] = _("Took all night to catch.");
const u8 gText_MatchCallPokeManiac_Steve_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPokeManiac_Steve_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallSwimmer_Tony_Strategy[] = _("Ram at full speed!");
const u8 gText_MatchCallSwimmer_Tony_Pokemon[] = _("Funky WATER type!");
const u8 gText_MatchCallSwimmer_Tony_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSwimmer_Tony_Intro2[] = _("I'll be pumping weights.");

const u8 gText_MatchCallBlackBelt_Nob_Strategy[] = _("Grand slam pummeling!");
const u8 gText_MatchCallBlackBelt_Nob_Pokemon[] = _("FIGHTING type.");
const u8 gText_MatchCallBlackBelt_Nob_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallBlackBelt_Nob_Intro2[] = _("ten roof tiles!");

const u8 gText_MatchCallBlackBelt_Koji_Strategy[] = _("Witness karate power!");
const u8 gText_MatchCallBlackBelt_Koji_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallBlackBelt_Koji_Intro1[] = _("Let us discuss matters of");
const u8 gText_MatchCallBlackBelt_Koji_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallGuitarist_Fernando_Strategy[] = _("Rock to stunning sounds!");
const u8 gText_MatchCallGuitarist_Fernando_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallGuitarist_Fernando_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallGuitarist_Fernando_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallGuitarist_Dalton_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallGuitarist_Dalton_Pokemon[] = _("They're ELECTRIC!");
const u8 gText_MatchCallGuitarist_Dalton_Intro1[] = _("I want to make people cry");
const u8 gText_MatchCallGuitarist_Dalton_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallKindler_Bernie_Strategy[] = _("Burn it all down!");
const u8 gText_MatchCallKindler_Bernie_Pokemon[] = _("Burn-inducing POKéMON.");
const u8 gText_MatchCallKindler_Bernie_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallKindler_Bernie_Intro2[] = _("be sure there's some water.");

const u8 gText_MatchCallCamper_Ethan_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallCamper_Ethan_Pokemon[] = _("I'll raise any POKéMON.");
const u8 gText_MatchCallCamper_Ethan_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallCamper_Ethan_Intro2[] = _("grow strong!");

const u8 gText_MatchCallOldCouple_JohnAndJay_Strategy[] = _("Our love lets us prevail.");
const u8 gText_MatchCallOldCouple_JohnAndJay_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallOldCouple_JohnAndJay_Intro1[] = _("Married 50 years, we've");
const u8 gText_MatchCallOldCouple_JohnAndJay_Intro2[] = _("devotedly raised POKéMON.");

const u8 gText_MatchCallBugManiac_Jeffrey_Strategy[] = _("Attack in waves!");
const u8 gText_MatchCallBugManiac_Jeffrey_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallBugManiac_Jeffrey_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallBugManiac_Jeffrey_Intro2[] = _("day to catch BUG POKéMON.");

const u8 gText_MatchCallPsychic_Cameron_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPsychic_Cameron_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPsychic_Cameron_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPsychic_Cameron_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallPsychic_Jacki_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPsychic_Jacki_Pokemon[] = _("POKéMON of many mysteries.");
const u8 gText_MatchCallPsychic_Jacki_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPsychic_Jacki_Intro2[] = _("using telepathy.");

const u8 gText_MatchCallGentleman_Walter_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallGentleman_Walter_Pokemon[] = _("POKéMON of distinction.");
const u8 gText_MatchCallGentleman_Walter_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallGentleman_Walter_Intro2[] = _("every day. It's imported.");

const u8 gText_MatchCallSchoolKid_Karen_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSchoolKid_Karen_Pokemon[] = _("I love any kind of POKéMON!");
const u8 gText_MatchCallSchoolKid_Karen_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSchoolKid_Karen_Intro2[] = _("money if I ace a test.");

const u8 gText_MatchCallSchoolKid_Jerry_Strategy[] = _("My knowledge rules!");
const u8 gText_MatchCallSchoolKid_Jerry_Pokemon[] = _("Any smart POKéMON!");
const u8 gText_MatchCallSchoolKid_Jerry_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSchoolKid_Jerry_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallSrAndJr_AnnaAndMeg_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSrAndJr_AnnaAndMeg_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSrAndJr_AnnaAndMeg_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSrAndJr_AnnaAndMeg_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallPokefan_Isabel_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPokefan_Isabel_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPokefan_Isabel_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPokefan_Isabel_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallPokefan_Miguel_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPokefan_Miguel_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPokefan_Miguel_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPokefan_Miguel_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallExpert_Timothy_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallExpert_Timothy_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallExpert_Timothy_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallExpert_Timothy_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallExpert_Shelby_Strategy[] = _("Attack while defending.");
const u8 gText_MatchCallExpert_Shelby_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallExpert_Shelby_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallExpert_Shelby_Intro2[] = _("style of battling.");

const u8 gText_MatchCallYoungster_Calvin_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallYoungster_Calvin_Pokemon[] = _("I use different types.");
const u8 gText_MatchCallYoungster_Calvin_Intro1[] = _("I'm going to keep working");
const u8 gText_MatchCallYoungster_Calvin_Intro2[] = _("until I beat a GYM LEADER.");

const u8 gText_MatchCallFisherman_Elliot_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallFisherman_Elliot_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallFisherman_Elliot_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallFisherman_Elliot_Intro2[] = _("catch a huge POKéMON!");

const u8 gText_MatchCallTriathlete_Isaiah_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTriathlete_Isaiah_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTriathlete_Isaiah_Intro1[] = _("I won't be beaten by some");
const u8 gText_MatchCallTriathlete_Isaiah_Intro2[] = _("beach bum SWIMMER!");

const u8 gText_MatchCallTriathlete_Maria_Strategy[] = _("Speed above all!");
const u8 gText_MatchCallTriathlete_Maria_Pokemon[] = _("I use a speedy POKéMON.");
const u8 gText_MatchCallTriathlete_Maria_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTriathlete_Maria_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallTriathlete_Abigail_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTriathlete_Abigail_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTriathlete_Abigail_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTriathlete_Abigail_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallTriathlete_Dylan_Strategy[] = _("Strike before stricken!");
const u8 gText_MatchCallTriathlete_Dylan_Pokemon[] = _("A fast-running POKéMON!");
const u8 gText_MatchCallTriathlete_Dylan_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTriathlete_Dylan_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallTriathlete_Katelyn_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTriathlete_Katelyn_Pokemon[] = _("WATER POKéMON rule!");
const u8 gText_MatchCallTriathlete_Katelyn_Intro1[] = _("I must swim over 6 miles");
const u8 gText_MatchCallTriathlete_Katelyn_Intro2[] = _("every day.");

const u8 gText_MatchCallTriathlete_Benjamin_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTriathlete_Benjamin_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTriathlete_Benjamin_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTriathlete_Benjamin_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallTriathlete_Pablo_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTriathlete_Pablo_Pokemon[] = _("Toughened WATER POKéMON.");
const u8 gText_MatchCallTriathlete_Pablo_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTriathlete_Pablo_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallDragonTamer_Nicolas_Strategy[] = _("It's about POKéMON power!");
const u8 gText_MatchCallDragonTamer_Nicolas_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallDragonTamer_Nicolas_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallDragonTamer_Nicolas_Intro2[] = _("strongest one day!");

const u8 gText_MatchCallBirdKeeper_Robert_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallBirdKeeper_Robert_Pokemon[] = _("Elegantly wheeling BIRDS.");
const u8 gText_MatchCallBirdKeeper_Robert_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallBirdKeeper_Robert_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallNinjaBoy_Lao_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallNinjaBoy_Lao_Pokemon[] = _("Poisonous POKéMON.");
const u8 gText_MatchCallNinjaBoy_Lao_Intro1[] = _("I undertake training so");
const u8 gText_MatchCallNinjaBoy_Lao_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallBattleGirl_Cyndy_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallBattleGirl_Cyndy_Pokemon[] = _("Speedy FIGHTING type.");
const u8 gText_MatchCallBattleGirl_Cyndy_Intro1[] = _("If my POKéMON lose,");
const u8 gText_MatchCallBattleGirl_Cyndy_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallParasolLady_Madeline_Strategy[] = _("Go, go, my POKéMON!");
const u8 gText_MatchCallParasolLady_Madeline_Pokemon[] = _("I'll raise anything.");
const u8 gText_MatchCallParasolLady_Madeline_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallParasolLady_Madeline_Intro2[] = _("enemy. Get protected.");

const u8 gText_MatchCallSwimmer_Jenny_Strategy[] = _("No mercy!");
const u8 gText_MatchCallSwimmer_Jenny_Pokemon[] = _("Cute WATER POKéMON.");
const u8 gText_MatchCallSwimmer_Jenny_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallSwimmer_Jenny_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallPicnicker_Diana_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPicnicker_Diana_Pokemon[] = _("I like all POKéMON.");
const u8 gText_MatchCallPicnicker_Diana_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPicnicker_Diana_Intro2[] = _("yonder hill?");

const u8 gText_MatchCallTwins_AmyAndLiv_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallTwins_AmyAndLiv_Pokemon[] = _("We train together!");
const u8 gText_MatchCallTwins_AmyAndLiv_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTwins_AmyAndLiv_Intro2[] = _("but different desserts.");

const u8 gText_MatchCallSailor_Ernest_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallSailor_Ernest_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallSailor_Ernest_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallSailor_Ernest_Intro2[] = _("Any complaints?");

const u8 gText_MatchCallSailor_Cory_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSailor_Cory_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSailor_Cory_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSailor_Cory_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallCollector_Edwin_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallCollector_Edwin_Pokemon[] = _("I love rare POKéMON.");
const u8 gText_MatchCallCollector_Edwin_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallCollector_Edwin_Intro2[] = _("world's rare POKéMON.");

const u8 gText_MatchCallPkmnBreeder_Lydia_Strategy[] = _("I count on power.");
const u8 gText_MatchCallPkmnBreeder_Lydia_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPkmnBreeder_Lydia_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPkmnBreeder_Lydia_Intro2[] = _("love to raise POKéMON.");

const u8 gText_MatchCallPkmnBreeder_Isaac_Strategy[] = _("Full-on attack!");
const u8 gText_MatchCallPkmnBreeder_Isaac_Pokemon[] = _("Anything. I'll raise it.");
const u8 gText_MatchCallPkmnBreeder_Isaac_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle. {POKEBLOCK}");
const u8 gText_MatchCallPkmnBreeder_Isaac_Intro2[] = _("going after CONTEST titles.");

const u8 gText_MatchCallPkmnBreeder_Gabrielle_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPkmnBreeder_Gabrielle_Pokemon[] = _("Fun-to-raise POKéMON.");
const u8 gText_MatchCallPkmnBreeder_Gabrielle_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPkmnBreeder_Gabrielle_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallPkmnRanger_Catherine_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPkmnRanger_Catherine_Pokemon[] = _("I like strong POKéMON.");
const u8 gText_MatchCallPkmnRanger_Catherine_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPkmnRanger_Catherine_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallPkmnRanger_Jackson_Strategy[] = _("Attack in waves!");
const u8 gText_MatchCallPkmnRanger_Jackson_Pokemon[] = _("I use different types.");
const u8 gText_MatchCallPkmnRanger_Jackson_Intro1[] = _("Those who destroy nature");
const u8 gText_MatchCallPkmnRanger_Jackson_Intro2[] = _("must never be forgiven!");

const u8 gText_MatchCallLass_Haley_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallLass_Haley_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallLass_Haley_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallLass_Haley_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallBugCatcher_James_Strategy[] = _("Lightning-fast attack!");
const u8 gText_MatchCallBugCatcher_James_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallBugCatcher_James_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallBugCatcher_James_Intro2[] = _("POKéMON, wake up early.");

const u8 gText_MatchCallHiker_Trent_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallHiker_Trent_Pokemon[] = _("Hard-bodied POKéMON.");
const u8 gText_MatchCallHiker_Trent_Intro1[] = _("I've been planning a month");
const u8 gText_MatchCallHiker_Trent_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallHiker_Sawyer_Strategy[] = _("I like it hot!");
const u8 gText_MatchCallHiker_Sawyer_Pokemon[] = _("Hot POKéMON!");
const u8 gText_MatchCallHiker_Sawyer_Intro1[] = _("As much as I love POKéMON,");
const u8 gText_MatchCallHiker_Sawyer_Intro2[] = _("I surely like hiking!");

const u8 gText_MatchCallYoungCouple_LoisAndHal_Strategy[] = _("Lovey-dovey strategy!");
const u8 gText_MatchCallYoungCouple_LoisAndHal_Pokemon[] = _("Lovey-dovey POKéMON!");
const u8 gText_MatchCallYoungCouple_LoisAndHal_Intro1[] = _("We're lovey-dovey!");
const u8 gText_MatchCallYoungCouple_LoisAndHal_Intro2[] = _("Forever lovey-dovey!");

const u8 gText_MatchCallPkmnTrainer_Wally_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPkmnTrainer_Wally_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPkmnTrainer_Wally_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallPkmnTrainer_Wally_Intro2[] = _("stronger together.");

const u8 gText_MatchCallRockinWhiz_Roxanne_Strategy[] = _("ROCK-type power attack.");
const u8 gText_MatchCallRockinWhiz_Roxanne_Pokemon[] = _("I prefer rock-hard POKéMON.");
const u8 gText_MatchCallRockinWhiz_Roxanne_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallRockinWhiz_Roxanne_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallTheBigHit_Brawly_Strategy[] = _("Direct physical action!");
const u8 gText_MatchCallTheBigHit_Brawly_Pokemon[] = _("FIGHTING POKéMON rule!");
const u8 gText_MatchCallTheBigHit_Brawly_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallTheBigHit_Brawly_Intro2[] = _("next big wave!");

const u8 gText_MatchCallSwellShock_Wattson_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallSwellShock_Wattson_Pokemon[] = _("Get shocked by electricity!");
const u8 gText_MatchCallSwellShock_Wattson_Intro1[] = _("One must never throw a");
const u8 gText_MatchCallSwellShock_Wattson_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallPassionBurn_Flannery_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPassionBurn_Flannery_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallPassionBurn_Flannery_Intro1[] = _("Completely wash away daily");
const u8 gText_MatchCallPassionBurn_Flannery_Intro2[] = _("fatigue in hot springs!");

const u8 gText_MatchCallReliableOne_Dad_Strategy[] = _("I flexibly adapt my style.");
const u8 gText_MatchCallReliableOne_Dad_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallReliableOne_Dad_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallReliableOne_Dad_Intro2[] = _("home to here every day.");

const u8 gText_MatchCallSkyTamer_Winona_Strategy[] = _("I take advantage of speed.");
const u8 gText_MatchCallSkyTamer_Winona_Pokemon[] = _("Graceful sky dancers.");
const u8 gText_MatchCallSkyTamer_Winona_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallSkyTamer_Winona_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallMysticDuo_TateAndLiza_Strategy[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallMysticDuo_TateAndLiza_Pokemon[] = _("Always friendly POKéMON.");
const u8 gText_MatchCallMysticDuo_TateAndLiza_Intro1[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallMysticDuo_TateAndLiza_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallDandyCharm_Juan_Strategy[] = _("I use splendid waterpower.");
const u8 gText_MatchCallDandyCharm_Juan_Pokemon[] = _("POKéMON of elegance!");
const u8 gText_MatchCallDandyCharm_Juan_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallDandyCharm_Juan_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallEliteFour_Sidney_Strategy[] = _("Offense over defense!");
const u8 gText_MatchCallEliteFour_Sidney_Pokemon[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallEliteFour_Sidney_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallEliteFour_Sidney_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallEliteFour_Phoebe_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallEliteFour_Phoebe_Pokemon[] = _("There's nothing definite.");
const u8 gText_MatchCallEliteFour_Phoebe_Intro1[] = _("I wonder how my grandma at");
const u8 gText_MatchCallEliteFour_Phoebe_Intro2[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");

const u8 gText_MatchCallEliteFour_Glacia_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallEliteFour_Glacia_Pokemon[] = _("Flaming passion in icy cold!");
const u8 gText_MatchCallEliteFour_Glacia_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallEliteFour_Glacia_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallEliteFour_Drake_Strategy[] = _("Harness strong abilities.");
const u8 gText_MatchCallEliteFour_Drake_Pokemon[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallEliteFour_Drake_Intro1[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");
const u8 gText_MatchCallEliteFour_Drake_Intro2[] = _("Abdel Edition : personne n'a demandé, mais le voilà.");

const u8 gText_MatchCallChampion_Wallace_Strategy[] = _("MESSAGE ABDEL : tout est parfaitement sous contrôle.");
const u8 gText_MatchCallChampion_Wallace_Pokemon[] = _("I prefer POKéMON of grace.");
const u8 gText_MatchCallChampion_Wallace_Intro1[] = _("I represent beauty as");
const u8 gText_MatchCallChampion_Wallace_Intro2[] = _("well as intelligence.");

const u8 *const gMatchCallFlavorTexts[REMATCH_TABLE_ENTRIES][CHECK_PAGE_ENTRY_COUNT] =
{
    [REMATCH_ROSE] = MCFLAVOR(AromaLady_Rose),
    [REMATCH_ANDRES] = MCFLAVOR(RuinManiac_Andres),
    [REMATCH_DUSTY] = MCFLAVOR(RuinManiac_Dusty),
    [REMATCH_LOLA] = MCFLAVOR(Tuber_Lola),
    [REMATCH_RICKY] = MCFLAVOR(Tuber_Ricky),
    [REMATCH_LILA_AND_ROY] = MCFLAVOR(SisAndBro_LilaAndRoy),
    [REMATCH_CRISTIN] = MCFLAVOR(Cooltrainer_Cristin),
    [REMATCH_BROOKE] = MCFLAVOR(Cooltrainer_Brooke),
    [REMATCH_WILTON] = MCFLAVOR(Cooltrainer_Wilton),
    [REMATCH_VALERIE] = MCFLAVOR(HexManiac_Valerie),
    [REMATCH_CINDY] = MCFLAVOR(Lady_Cindy),
    [REMATCH_THALIA] = MCFLAVOR(Beauty_Thalia),
    [REMATCH_JESSICA] = MCFLAVOR(Beauty_Jessica),
    [REMATCH_WINSTON] = MCFLAVOR(RichBoy_Winston),
    [REMATCH_STEVE] = MCFLAVOR(PokeManiac_Steve),
    [REMATCH_TONY] = MCFLAVOR(Swimmer_Tony),
    [REMATCH_NOB] = MCFLAVOR(BlackBelt_Nob),
    [REMATCH_KOJI] = MCFLAVOR(BlackBelt_Koji),
    [REMATCH_FERNANDO] = MCFLAVOR(Guitarist_Fernando),
    [REMATCH_DALTON] = MCFLAVOR(Guitarist_Dalton),
    [REMATCH_BERNIE] = MCFLAVOR(Kindler_Bernie),
    [REMATCH_ETHAN] = MCFLAVOR(Camper_Ethan),
    [REMATCH_JOHN_AND_JAY] = MCFLAVOR(OldCouple_JohnAndJay),
    [REMATCH_JEFFREY] = MCFLAVOR(BugManiac_Jeffrey),
    [REMATCH_CAMERON] = MCFLAVOR(Psychic_Cameron),
    [REMATCH_JACKI] = MCFLAVOR(Psychic_Jacki),
    [REMATCH_WALTER] = MCFLAVOR(Gentleman_Walter),
    [REMATCH_KAREN] = MCFLAVOR(SchoolKid_Karen),
    [REMATCH_JERRY] = MCFLAVOR(SchoolKid_Jerry),
    [REMATCH_ANNA_AND_MEG] = MCFLAVOR(SrAndJr_AnnaAndMeg),
    [REMATCH_ISABEL] = MCFLAVOR(Pokefan_Isabel),
    [REMATCH_MIGUEL] = MCFLAVOR(Pokefan_Miguel),
    [REMATCH_TIMOTHY] = MCFLAVOR(Expert_Timothy),
    [REMATCH_SHELBY] = MCFLAVOR(Expert_Shelby),
    [REMATCH_CALVIN] = MCFLAVOR(Youngster_Calvin),
    [REMATCH_ELLIOT] = MCFLAVOR(Fisherman_Elliot),
    [REMATCH_ISAIAH] = MCFLAVOR(Triathlete_Isaiah),
    [REMATCH_MARIA] = MCFLAVOR(Triathlete_Maria),
    [REMATCH_ABIGAIL] = MCFLAVOR(Triathlete_Abigail),
    [REMATCH_DYLAN] = MCFLAVOR(Triathlete_Dylan),
    [REMATCH_KATELYN] = MCFLAVOR(Triathlete_Katelyn),
    [REMATCH_BENJAMIN] = MCFLAVOR(Triathlete_Benjamin),
    [REMATCH_PABLO] = MCFLAVOR(Triathlete_Pablo),
    [REMATCH_NICOLAS] = MCFLAVOR(DragonTamer_Nicolas),
    [REMATCH_ROBERT] = MCFLAVOR(BirdKeeper_Robert),
    [REMATCH_LAO] = MCFLAVOR(NinjaBoy_Lao),
    [REMATCH_CYNDY] = MCFLAVOR(BattleGirl_Cyndy),
    [REMATCH_MADELINE] = MCFLAVOR(ParasolLady_Madeline),
    [REMATCH_JENNY] = MCFLAVOR(Swimmer_Jenny),
    [REMATCH_DIANA] = MCFLAVOR(Picnicker_Diana),
    [REMATCH_AMY_AND_LIV] = MCFLAVOR(Twins_AmyAndLiv),
    [REMATCH_ERNEST] = MCFLAVOR(Sailor_Ernest),
    [REMATCH_CORY] = MCFLAVOR(Sailor_Cory),
    [REMATCH_EDWIN] = MCFLAVOR(Collector_Edwin),
    [REMATCH_LYDIA] = MCFLAVOR(PkmnBreeder_Lydia),
    [REMATCH_ISAAC] = MCFLAVOR(PkmnBreeder_Isaac),
    [REMATCH_GABRIELLE] = MCFLAVOR(PkmnBreeder_Gabrielle),
    [REMATCH_CATHERINE] = MCFLAVOR(PkmnRanger_Catherine),
    [REMATCH_JACKSON] = MCFLAVOR(PkmnRanger_Jackson),
    [REMATCH_HALEY] = MCFLAVOR(Lass_Haley),
    [REMATCH_JAMES] = MCFLAVOR(BugCatcher_James),
    [REMATCH_TRENT] = MCFLAVOR(Hiker_Trent),
    [REMATCH_SAWYER] = MCFLAVOR(Hiker_Sawyer),
    [REMATCH_KIRA_AND_DAN] = MCFLAVOR(YoungCouple_LoisAndHal),
    [REMATCH_WALLY_VR] = MCFLAVOR(PkmnTrainer_Wally),
    [REMATCH_ROXANNE] = MCFLAVOR(RockinWhiz_Roxanne),
    [REMATCH_BRAWLY] = MCFLAVOR(TheBigHit_Brawly),
    [REMATCH_WATTSON] = MCFLAVOR(SwellShock_Wattson),
    [REMATCH_FLANNERY] = MCFLAVOR(PassionBurn_Flannery),
    [REMATCH_NORMAN] = MCFLAVOR(ReliableOne_Dad),
    [REMATCH_WINONA] = MCFLAVOR(SkyTamer_Winona),
    [REMATCH_TATE_AND_LIZA] = MCFLAVOR(MysticDuo_TateAndLiza),
    [REMATCH_JUAN] = MCFLAVOR(DandyCharm_Juan),
    [REMATCH_SIDNEY] = MCFLAVOR(EliteFour_Sidney),
    [REMATCH_PHOEBE] = MCFLAVOR(EliteFour_Phoebe),
    [REMATCH_GLACIA] = MCFLAVOR(EliteFour_Glacia),
    [REMATCH_DRAKE] = MCFLAVOR(EliteFour_Drake),
    [REMATCH_WALLACE] = MCFLAVOR(Champion_Wallace),
};
