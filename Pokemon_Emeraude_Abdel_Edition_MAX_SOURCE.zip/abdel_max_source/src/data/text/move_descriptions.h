static const u8 sNullDescription[] = _(
    "");

static const u8 sPoundDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sKarateChopDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sDoubleSlapDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sCometPunchDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMegaPunchDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sPayDayDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sFirePunchDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sIcePunchDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sThunderPunchDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sScratchDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sViceGripDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sGuillotineDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sRazorWindDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSwordsDanceDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sCutDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sGustDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sWingAttackDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sWhirlwindDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFlyDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBindDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSlamDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sVineWhipDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sStompDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDoubleKickDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMegaKickDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sJumpKickDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRollingKickDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSandAttackDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sHeadbuttDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHornAttackDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sFuryAttackDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sHornDrillDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sTackleDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBodySlamDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWrapDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTakeDownDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sThrashDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sDoubleEdgeDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTailWhipDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPoisonStingDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTwineedleDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sPinMissileDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sLeerDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBiteDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sGrowlDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRoarDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSingDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSupersonicDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSonicBoomDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sDisableDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sAcidDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sEmberDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sFlamethrowerDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMistDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWaterGunDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sHydroPumpDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSurfDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sIceBeamDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBlizzardDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPsybeamDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBubbleBeamDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sAuroraBeamDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sHyperBeamDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPeckDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sDrillPeckDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSubmissionDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sLowKickDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sCounterDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSeismicTossDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sStrengthDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sAbsorbDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sMegaDrainDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sLeechSeedDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sGrowthDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRazorLeafDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSolarBeamDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sPoisonPowderDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sStunSporeDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSleepPowderDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPetalDanceDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sStringShotDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sDragonRageDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sFireSpinDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sThunderShockDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sThunderboltDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sThunderWaveDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sThunderDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sRockThrowDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sEarthquakeDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sFissureDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sDigDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sToxicDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sConfusionDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPsychicDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHypnosisDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMeditateDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sAgilityDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sQuickAttackDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sRageDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sTeleportDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sNightShadeDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sMimicDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sScreechDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDoubleTeamDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sRecoverDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sHardenDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sMinimizeDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSmokescreenDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sConfuseRayDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWithdrawDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sDefenseCurlDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sBarrierDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sLightScreenDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sHazeDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sReflectDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sFocusEnergyDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sBideDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sMetronomeDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMirrorMoveDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSelfDestructDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sEggBombDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sLickDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSmogDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSludgeDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBoneClubDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sFireBlastDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sWaterfallDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sClampDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSwiftDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSkullBashDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSpikeCannonDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sConstrictDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sAmnesiaDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sKinesisDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSoftBoiledDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sHiJumpKickDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sGlareDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sDreamEaterDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPoisonGasDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBarrageDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sLeechLifeDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sLovelyKissDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSkyAttackDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sTransformDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBubbleDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sDizzyPunchDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSporeDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sFlashDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPsywaveDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSplashDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sAcidArmorDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sCrabhammerDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sExplosionDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFurySwipesDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBonemerangDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRestDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRockSlideDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sHyperFangDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSharpenDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sConversionDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sTriAttackDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSuperFangDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSlashDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSubstituteDescription[] = _(
    "Creates a decoy using 1/4\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sStruggleDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSketchDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sTripleKickDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sThiefDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSpiderWebDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMindReaderDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sNightmareDescription[] = _(
    "Inflige des dégâts. Parce que oui, c’est le principe.
"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sFlameWheelDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSnoreDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sCurseDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFlailDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sConversion2Description[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sAeroblastDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sCottonSporeDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sReversalDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSpiteDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sPowderSnowDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sProtectDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sMachPunchDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sScaryFaceDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFaintAttackDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSweetKissDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBellyDrumDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSludgeBombDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sMudSlapDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sOctazookaDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSpikesDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sZapCannonDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sForesightDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sDestinyBondDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPerishSongDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sIcyWindDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sDetectDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sBoneRushDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sLockOnDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sOutrageDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSandstormDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sGigaDrainDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sEndureDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sCharmDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sRolloutDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sFalseSwipeDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSwaggerDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sMilkDrinkDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSparkDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFuryCutterDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSteelWingDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMeanLookDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sAttractDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSleepTalkDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sHealBellDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sReturnDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sPresentDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sFrustrationDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSafeguardDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPainSplitDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSacredFireDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMagnitudeDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sDynamicPunchDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sMegahornDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sDragonBreathDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBatonPassDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sEncoreDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sPursuitDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sRapidSpinDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSweetScentDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sIronTailDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMetalClawDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sVitalThrowDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sMorningSunDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSynthesisDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMoonlightDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sHiddenPowerDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sCrossChopDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sTwisterDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sRainDanceDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSunnyDayDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sCrunchDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sMirrorCoatDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sPsychUpDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sExtremeSpeedDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sAncientPowerDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sShadowBallDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sFutureSightDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sRockSmashDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sWhirlpoolDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBeatUpDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sFakeOutDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sUproarDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sStockpileDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSpitUpDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSwallowDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sHeatWaveDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sHailDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sTormentDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sFlatterDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWillOWispDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMementoDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sFacadeDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sFocusPunchDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSmellingSaltDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sFollowMeDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sNaturePowerDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sChargeDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sTauntDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sHelpingHandDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sTrickDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRolePlayDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sWishDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sAssistDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sIngrainDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sSuperpowerDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sMagicCoatDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sRecycleDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sRevengeDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBrickBreakDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sYawnDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sKnockOffDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sEndeavorDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sEruptionDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSkillSwapDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sImprisonDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRefreshDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sGrudgeDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSnatchDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sSecretPowerDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sDiveDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sArmThrustDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sCamouflageDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sTailGlowDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sLusterPurgeDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMistBallDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sFeatherDanceDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sTeeterDanceDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sBlazeKickDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMudSportDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sIceBallDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sNeedleArmDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSlackOffDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sHyperVoiceDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sPoisonFangDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sCrushClawDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sBlastBurnDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sHydroCannonDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sMeteorMashDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sAstonishDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWeatherBallDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sAromatherapyDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sFakeTearsDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sAirCutterDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sOverheatDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sOdorSleuthDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sRockTombDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSilverWindDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sMetalSoundDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sGrassWhistleDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sTickleDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sCosmicPowerDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sWaterSpoutDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSignalBeamDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sShadowPunchDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sExtrasensoryDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sSkyUppercutDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sSandTombDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sSheerColdDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMuddyWaterDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sBulletSeedDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sAerialAceDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sIcicleSpearDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sIronDefenseDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBlockDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sHowlDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sDragonClawDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sFrenzyPlantDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sBulkUpDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sBounceDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sMudShotDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sPoisonTailDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sCovetDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sVoltTackleDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sMagicalLeafDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sWaterSportDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sCalmMindDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sLeafBladeDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sDragonDanceDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

static const u8 sRockBlastDescription[] = _(
    "Un truc utile, bizarre et parfaitement Pokémon.\n"
    "Ça fait quelque chose. C'est déjà bien.");

static const u8 sShockWaveDescription[] = _(
    "Une description très sérieuse. Enfin, presque.\n"
    "Un truc utile, bizarre et parfaitement Pokémon.");

static const u8 sWaterPulseDescription[] = _(
    "Abdel recommande : ne pas poser de questions.\n"
    "Une description très sérieuse. Enfin, presque.");

static const u8 sDoomDesireDescription[] = _(
    "Une merveille de technologie douteuse.\n"
    "Abdel recommande : ne pas poser de questions.");

static const u8 sPsychoBoostDescription[] = _(
    "Ça fait quelque chose. C'est déjà bien.\n"
    "Une merveille de technologie douteuse.");

// MOVE_NONE is ignored in this table. Make sure to always subtract 1 before getting the right pointer.
const u8 *const gMoveDescriptionPointers[MOVES_COUNT - 1] =
{
    [MOVE_POUND - 1] = sPoundDescription,
    [MOVE_KARATE_CHOP - 1] = sKarateChopDescription,
    [MOVE_DOUBLE_SLAP - 1] = sDoubleSlapDescription,
    [MOVE_COMET_PUNCH - 1] = sCometPunchDescription,
    [MOVE_MEGA_PUNCH - 1] = sMegaPunchDescription,
    [MOVE_PAY_DAY - 1] = sPayDayDescription,
    [MOVE_FIRE_PUNCH - 1] = sFirePunchDescription,
    [MOVE_ICE_PUNCH - 1] = sIcePunchDescription,
    [MOVE_THUNDER_PUNCH - 1] = sThunderPunchDescription,
    [MOVE_SCRATCH - 1] = sScratchDescription,
    [MOVE_VICE_GRIP - 1] = sViceGripDescription,
    [MOVE_GUILLOTINE - 1] = sGuillotineDescription,
    [MOVE_RAZOR_WIND - 1] = sRazorWindDescription,
    [MOVE_SWORDS_DANCE - 1] = sSwordsDanceDescription,
    [MOVE_CUT - 1] = sCutDescription,
    [MOVE_GUST - 1] = sGustDescription,
    [MOVE_WING_ATTACK - 1] = sWingAttackDescription,
    [MOVE_WHIRLWIND - 1] = sWhirlwindDescription,
    [MOVE_FLY - 1] = sFlyDescription,
    [MOVE_BIND - 1] = sBindDescription,
    [MOVE_SLAM - 1] = sSlamDescription,
    [MOVE_VINE_WHIP - 1] = sVineWhipDescription,
    [MOVE_STOMP - 1] = sStompDescription,
    [MOVE_DOUBLE_KICK - 1] = sDoubleKickDescription,
    [MOVE_MEGA_KICK - 1] = sMegaKickDescription,
    [MOVE_JUMP_KICK - 1] = sJumpKickDescription,
    [MOVE_ROLLING_KICK - 1] = sRollingKickDescription,
    [MOVE_SAND_ATTACK - 1] = sSandAttackDescription,
    [MOVE_HEADBUTT - 1] = sHeadbuttDescription,
    [MOVE_HORN_ATTACK - 1] = sHornAttackDescription,
    [MOVE_FURY_ATTACK - 1] = sFuryAttackDescription,
    [MOVE_HORN_DRILL - 1] = sHornDrillDescription,
    [MOVE_TACKLE - 1] = sTackleDescription,
    [MOVE_BODY_SLAM - 1] = sBodySlamDescription,
    [MOVE_WRAP - 1] = sWrapDescription,
    [MOVE_TAKE_DOWN - 1] = sTakeDownDescription,
    [MOVE_THRASH - 1] = sThrashDescription,
    [MOVE_DOUBLE_EDGE - 1] = sDoubleEdgeDescription,
    [MOVE_TAIL_WHIP - 1] = sTailWhipDescription,
    [MOVE_POISON_STING - 1] = sPoisonStingDescription,
    [MOVE_TWINEEDLE - 1] = sTwineedleDescription,
    [MOVE_PIN_MISSILE - 1] = sPinMissileDescription,
    [MOVE_LEER - 1] = sLeerDescription,
    [MOVE_BITE - 1] = sBiteDescription,
    [MOVE_GROWL - 1] = sGrowlDescription,
    [MOVE_ROAR - 1] = sRoarDescription,
    [MOVE_SING - 1] = sSingDescription,
    [MOVE_SUPERSONIC - 1] = sSupersonicDescription,
    [MOVE_SONIC_BOOM - 1] = sSonicBoomDescription,
    [MOVE_DISABLE - 1] = sDisableDescription,
    [MOVE_ACID - 1] = sAcidDescription,
    [MOVE_EMBER - 1] = sEmberDescription,
    [MOVE_FLAMETHROWER - 1] = sFlamethrowerDescription,
    [MOVE_MIST - 1] = sMistDescription,
    [MOVE_WATER_GUN - 1] = sWaterGunDescription,
    [MOVE_HYDRO_PUMP - 1] = sHydroPumpDescription,
    [MOVE_SURF - 1] = sSurfDescription,
    [MOVE_ICE_BEAM - 1] = sIceBeamDescription,
    [MOVE_BLIZZARD - 1] = sBlizzardDescription,
    [MOVE_PSYBEAM - 1] = sPsybeamDescription,
    [MOVE_BUBBLE_BEAM - 1] = sBubbleBeamDescription,
    [MOVE_AURORA_BEAM - 1] = sAuroraBeamDescription,
    [MOVE_HYPER_BEAM - 1] = sHyperBeamDescription,
    [MOVE_PECK - 1] = sPeckDescription,
    [MOVE_DRILL_PECK - 1] = sDrillPeckDescription,
    [MOVE_SUBMISSION - 1] = sSubmissionDescription,
    [MOVE_LOW_KICK - 1] = sLowKickDescription,
    [MOVE_COUNTER - 1] = sCounterDescription,
    [MOVE_SEISMIC_TOSS - 1] = sSeismicTossDescription,
    [MOVE_STRENGTH - 1] = sStrengthDescription,
    [MOVE_ABSORB - 1] = sAbsorbDescription,
    [MOVE_MEGA_DRAIN - 1] = sMegaDrainDescription,
    [MOVE_LEECH_SEED - 1] = sLeechSeedDescription,
    [MOVE_GROWTH - 1] = sGrowthDescription,
    [MOVE_RAZOR_LEAF - 1] = sRazorLeafDescription,
    [MOVE_SOLAR_BEAM - 1] = sSolarBeamDescription,
    [MOVE_POISON_POWDER - 1] = sPoisonPowderDescription,
    [MOVE_STUN_SPORE - 1] = sStunSporeDescription,
    [MOVE_SLEEP_POWDER - 1] = sSleepPowderDescription,
    [MOVE_PETAL_DANCE - 1] = sPetalDanceDescription,
    [MOVE_STRING_SHOT - 1] = sStringShotDescription,
    [MOVE_DRAGON_RAGE - 1] = sDragonRageDescription,
    [MOVE_FIRE_SPIN - 1] = sFireSpinDescription,
    [MOVE_THUNDER_SHOCK - 1] = sThunderShockDescription,
    [MOVE_THUNDERBOLT - 1] = sThunderboltDescription,
    [MOVE_THUNDER_WAVE - 1] = sThunderWaveDescription,
    [MOVE_THUNDER - 1] = sThunderDescription,
    [MOVE_ROCK_THROW - 1] = sRockThrowDescription,
    [MOVE_EARTHQUAKE - 1] = sEarthquakeDescription,
    [MOVE_FISSURE - 1] = sFissureDescription,
    [MOVE_DIG - 1] = sDigDescription,
    [MOVE_TOXIC - 1] = sToxicDescription,
    [MOVE_CONFUSION - 1] = sConfusionDescription,
    [MOVE_PSYCHIC - 1] = sPsychicDescription,
    [MOVE_HYPNOSIS - 1] = sHypnosisDescription,
    [MOVE_MEDITATE - 1] = sMeditateDescription,
    [MOVE_AGILITY - 1] = sAgilityDescription,
    [MOVE_QUICK_ATTACK - 1] = sQuickAttackDescription,
    [MOVE_RAGE - 1] = sRageDescription,
    [MOVE_TELEPORT - 1] = sTeleportDescription,
    [MOVE_NIGHT_SHADE - 1] = sNightShadeDescription,
    [MOVE_MIMIC - 1] = sMimicDescription,
    [MOVE_SCREECH - 1] = sScreechDescription,
    [MOVE_DOUBLE_TEAM - 1] = sDoubleTeamDescription,
    [MOVE_RECOVER - 1] = sRecoverDescription,
    [MOVE_HARDEN - 1] = sHardenDescription,
    [MOVE_MINIMIZE - 1] = sMinimizeDescription,
    [MOVE_SMOKESCREEN - 1] = sSmokescreenDescription,
    [MOVE_CONFUSE_RAY - 1] = sConfuseRayDescription,
    [MOVE_WITHDRAW - 1] = sWithdrawDescription,
    [MOVE_DEFENSE_CURL - 1] = sDefenseCurlDescription,
    [MOVE_BARRIER - 1] = sBarrierDescription,
    [MOVE_LIGHT_SCREEN - 1] = sLightScreenDescription,
    [MOVE_HAZE - 1] = sHazeDescription,
    [MOVE_REFLECT - 1] = sReflectDescription,
    [MOVE_FOCUS_ENERGY - 1] = sFocusEnergyDescription,
    [MOVE_BIDE - 1] = sBideDescription,
    [MOVE_METRONOME - 1] = sMetronomeDescription,
    [MOVE_MIRROR_MOVE - 1] = sMirrorMoveDescription,
    [MOVE_SELF_DESTRUCT - 1] = sSelfDestructDescription,
    [MOVE_EGG_BOMB - 1] = sEggBombDescription,
    [MOVE_LICK - 1] = sLickDescription,
    [MOVE_SMOG - 1] = sSmogDescription,
    [MOVE_SLUDGE - 1] = sSludgeDescription,
    [MOVE_BONE_CLUB - 1] = sBoneClubDescription,
    [MOVE_FIRE_BLAST - 1] = sFireBlastDescription,
    [MOVE_WATERFALL - 1] = sWaterfallDescription,
    [MOVE_CLAMP - 1] = sClampDescription,
    [MOVE_SWIFT - 1] = sSwiftDescription,
    [MOVE_SKULL_BASH - 1] = sSkullBashDescription,
    [MOVE_SPIKE_CANNON - 1] = sSpikeCannonDescription,
    [MOVE_CONSTRICT - 1] = sConstrictDescription,
    [MOVE_AMNESIA - 1] = sAmnesiaDescription,
    [MOVE_KINESIS - 1] = sKinesisDescription,
    [MOVE_SOFT_BOILED - 1] = sSoftBoiledDescription,
    [MOVE_HI_JUMP_KICK - 1] = sHiJumpKickDescription,
    [MOVE_GLARE - 1] = sGlareDescription,
    [MOVE_DREAM_EATER - 1] = sDreamEaterDescription,
    [MOVE_POISON_GAS - 1] = sPoisonGasDescription,
    [MOVE_BARRAGE - 1] = sBarrageDescription,
    [MOVE_LEECH_LIFE - 1] = sLeechLifeDescription,
    [MOVE_LOVELY_KISS - 1] = sLovelyKissDescription,
    [MOVE_SKY_ATTACK - 1] = sSkyAttackDescription,
    [MOVE_TRANSFORM - 1] = sTransformDescription,
    [MOVE_BUBBLE - 1] = sBubbleDescription,
    [MOVE_DIZZY_PUNCH - 1] = sDizzyPunchDescription,
    [MOVE_SPORE - 1] = sSporeDescription,
    [MOVE_FLASH - 1] = sFlashDescription,
    [MOVE_PSYWAVE - 1] = sPsywaveDescription,
    [MOVE_SPLASH - 1] = sSplashDescription,
    [MOVE_ACID_ARMOR - 1] = sAcidArmorDescription,
    [MOVE_CRABHAMMER - 1] = sCrabhammerDescription,
    [MOVE_EXPLOSION - 1] = sExplosionDescription,
    [MOVE_FURY_SWIPES - 1] = sFurySwipesDescription,
    [MOVE_BONEMERANG - 1] = sBonemerangDescription,
    [MOVE_REST - 1] = sRestDescription,
    [MOVE_ROCK_SLIDE - 1] = sRockSlideDescription,
    [MOVE_HYPER_FANG - 1] = sHyperFangDescription,
    [MOVE_SHARPEN - 1] = sSharpenDescription,
    [MOVE_CONVERSION - 1] = sConversionDescription,
    [MOVE_TRI_ATTACK - 1] = sTriAttackDescription,
    [MOVE_SUPER_FANG - 1] = sSuperFangDescription,
    [MOVE_SLASH - 1] = sSlashDescription,
    [MOVE_SUBSTITUTE - 1] = sSubstituteDescription,
    [MOVE_STRUGGLE - 1] = sStruggleDescription,
    [MOVE_SKETCH - 1] = sSketchDescription,
    [MOVE_TRIPLE_KICK - 1] = sTripleKickDescription,
    [MOVE_THIEF - 1] = sThiefDescription,
    [MOVE_SPIDER_WEB - 1] = sSpiderWebDescription,
    [MOVE_MIND_READER - 1] = sMindReaderDescription,
    [MOVE_NIGHTMARE - 1] = sNightmareDescription,
    [MOVE_FLAME_WHEEL - 1] = sFlameWheelDescription,
    [MOVE_SNORE - 1] = sSnoreDescription,
    [MOVE_CURSE - 1] = sCurseDescription,
    [MOVE_FLAIL - 1] = sFlailDescription,
    [MOVE_CONVERSION_2 - 1] = sConversion2Description,
    [MOVE_AEROBLAST - 1] = sAeroblastDescription,
    [MOVE_COTTON_SPORE - 1] = sCottonSporeDescription,
    [MOVE_REVERSAL - 1] = sReversalDescription,
    [MOVE_SPITE - 1] = sSpiteDescription,
    [MOVE_POWDER_SNOW - 1] = sPowderSnowDescription,
    [MOVE_PROTECT - 1] = sProtectDescription,
    [MOVE_MACH_PUNCH - 1] = sMachPunchDescription,
    [MOVE_SCARY_FACE - 1] = sScaryFaceDescription,
    [MOVE_FAINT_ATTACK - 1] = sFaintAttackDescription,
    [MOVE_SWEET_KISS - 1] = sSweetKissDescription,
    [MOVE_BELLY_DRUM - 1] = sBellyDrumDescription,
    [MOVE_SLUDGE_BOMB - 1] = sSludgeBombDescription,
    [MOVE_MUD_SLAP - 1] = sMudSlapDescription,
    [MOVE_OCTAZOOKA - 1] = sOctazookaDescription,
    [MOVE_SPIKES - 1] = sSpikesDescription,
    [MOVE_ZAP_CANNON - 1] = sZapCannonDescription,
    [MOVE_FORESIGHT - 1] = sForesightDescription,
    [MOVE_DESTINY_BOND - 1] = sDestinyBondDescription,
    [MOVE_PERISH_SONG - 1] = sPerishSongDescription,
    [MOVE_ICY_WIND - 1] = sIcyWindDescription,
    [MOVE_DETECT - 1] = sDetectDescription,
    [MOVE_BONE_RUSH - 1] = sBoneRushDescription,
    [MOVE_LOCK_ON - 1] = sLockOnDescription,
    [MOVE_OUTRAGE - 1] = sOutrageDescription,
    [MOVE_SANDSTORM - 1] = sSandstormDescription,
    [MOVE_GIGA_DRAIN - 1] = sGigaDrainDescription,
    [MOVE_ENDURE - 1] = sEndureDescription,
    [MOVE_CHARM - 1] = sCharmDescription,
    [MOVE_ROLLOUT - 1] = sRolloutDescription,
    [MOVE_FALSE_SWIPE - 1] = sFalseSwipeDescription,
    [MOVE_SWAGGER - 1] = sSwaggerDescription,
    [MOVE_MILK_DRINK - 1] = sMilkDrinkDescription,
    [MOVE_SPARK - 1] = sSparkDescription,
    [MOVE_FURY_CUTTER - 1] = sFuryCutterDescription,
    [MOVE_STEEL_WING - 1] = sSteelWingDescription,
    [MOVE_MEAN_LOOK - 1] = sMeanLookDescription,
    [MOVE_ATTRACT - 1] = sAttractDescription,
    [MOVE_SLEEP_TALK - 1] = sSleepTalkDescription,
    [MOVE_HEAL_BELL - 1] = sHealBellDescription,
    [MOVE_RETURN - 1] = sReturnDescription,
    [MOVE_PRESENT - 1] = sPresentDescription,
    [MOVE_FRUSTRATION - 1] = sFrustrationDescription,
    [MOVE_SAFEGUARD - 1] = sSafeguardDescription,
    [MOVE_PAIN_SPLIT - 1] = sPainSplitDescription,
    [MOVE_SACRED_FIRE - 1] = sSacredFireDescription,
    [MOVE_MAGNITUDE - 1] = sMagnitudeDescription,
    [MOVE_DYNAMIC_PUNCH - 1] = sDynamicPunchDescription,
    [MOVE_MEGAHORN - 1] = sMegahornDescription,
    [MOVE_DRAGON_BREATH - 1] = sDragonBreathDescription,
    [MOVE_BATON_PASS - 1] = sBatonPassDescription,
    [MOVE_ENCORE - 1] = sEncoreDescription,
    [MOVE_PURSUIT - 1] = sPursuitDescription,
    [MOVE_RAPID_SPIN - 1] = sRapidSpinDescription,
    [MOVE_SWEET_SCENT - 1] = sSweetScentDescription,
    [MOVE_IRON_TAIL - 1] = sIronTailDescription,
    [MOVE_METAL_CLAW - 1] = sMetalClawDescription,
    [MOVE_VITAL_THROW - 1] = sVitalThrowDescription,
    [MOVE_MORNING_SUN - 1] = sMorningSunDescription,
    [MOVE_SYNTHESIS - 1] = sSynthesisDescription,
    [MOVE_MOONLIGHT - 1] = sMoonlightDescription,
    [MOVE_HIDDEN_POWER - 1] = sHiddenPowerDescription,
    [MOVE_CROSS_CHOP - 1] = sCrossChopDescription,
    [MOVE_TWISTER - 1] = sTwisterDescription,
    [MOVE_RAIN_DANCE - 1] = sRainDanceDescription,
    [MOVE_SUNNY_DAY - 1] = sSunnyDayDescription,
    [MOVE_CRUNCH - 1] = sCrunchDescription,
    [MOVE_MIRROR_COAT - 1] = sMirrorCoatDescription,
    [MOVE_PSYCH_UP - 1] = sPsychUpDescription,
    [MOVE_EXTREME_SPEED - 1] = sExtremeSpeedDescription,
    [MOVE_ANCIENT_POWER - 1] = sAncientPowerDescription,
    [MOVE_SHADOW_BALL - 1] = sShadowBallDescription,
    [MOVE_FUTURE_SIGHT - 1] = sFutureSightDescription,
    [MOVE_ROCK_SMASH - 1] = sRockSmashDescription,
    [MOVE_WHIRLPOOL - 1] = sWhirlpoolDescription,
    [MOVE_BEAT_UP - 1] = sBeatUpDescription,
    [MOVE_FAKE_OUT - 1] = sFakeOutDescription,
    [MOVE_UPROAR - 1] = sUproarDescription,
    [MOVE_STOCKPILE - 1] = sStockpileDescription,
    [MOVE_SPIT_UP - 1] = sSpitUpDescription,
    [MOVE_SWALLOW - 1] = sSwallowDescription,
    [MOVE_HEAT_WAVE - 1] = sHeatWaveDescription,
    [MOVE_HAIL - 1] = sHailDescription,
    [MOVE_TORMENT - 1] = sTormentDescription,
    [MOVE_FLATTER - 1] = sFlatterDescription,
    [MOVE_WILL_O_WISP - 1] = sWillOWispDescription,
    [MOVE_MEMENTO - 1] = sMementoDescription,
    [MOVE_FACADE - 1] = sFacadeDescription,
    [MOVE_FOCUS_PUNCH - 1] = sFocusPunchDescription,
    [MOVE_SMELLING_SALT - 1] = sSmellingSaltDescription,
    [MOVE_FOLLOW_ME - 1] = sFollowMeDescription,
    [MOVE_NATURE_POWER - 1] = sNaturePowerDescription,
    [MOVE_CHARGE - 1] = sChargeDescription,
    [MOVE_TAUNT - 1] = sTauntDescription,
    [MOVE_HELPING_HAND - 1] = sHelpingHandDescription,
    [MOVE_TRICK - 1] = sTrickDescription,
    [MOVE_ROLE_PLAY - 1] = sRolePlayDescription,
    [MOVE_WISH - 1] = sWishDescription,
    [MOVE_ASSIST - 1] = sAssistDescription,
    [MOVE_INGRAIN - 1] = sIngrainDescription,
    [MOVE_SUPERPOWER - 1] = sSuperpowerDescription,
    [MOVE_MAGIC_COAT - 1] = sMagicCoatDescription,
    [MOVE_RECYCLE - 1] = sRecycleDescription,
    [MOVE_REVENGE - 1] = sRevengeDescription,
    [MOVE_BRICK_BREAK - 1] = sBrickBreakDescription,
    [MOVE_YAWN - 1] = sYawnDescription,
    [MOVE_KNOCK_OFF - 1] = sKnockOffDescription,
    [MOVE_ENDEAVOR - 1] = sEndeavorDescription,
    [MOVE_ERUPTION - 1] = sEruptionDescription,
    [MOVE_SKILL_SWAP - 1] = sSkillSwapDescription,
    [MOVE_IMPRISON - 1] = sImprisonDescription,
    [MOVE_REFRESH - 1] = sRefreshDescription,
    [MOVE_GRUDGE - 1] = sGrudgeDescription,
    [MOVE_SNATCH - 1] = sSnatchDescription,
    [MOVE_SECRET_POWER - 1] = sSecretPowerDescription,
    [MOVE_DIVE - 1] = sDiveDescription,
    [MOVE_ARM_THRUST - 1] = sArmThrustDescription,
    [MOVE_CAMOUFLAGE - 1] = sCamouflageDescription,
    [MOVE_TAIL_GLOW - 1] = sTailGlowDescription,
    [MOVE_LUSTER_PURGE - 1] = sLusterPurgeDescription,
    [MOVE_MIST_BALL - 1] = sMistBallDescription,
    [MOVE_FEATHER_DANCE - 1] = sFeatherDanceDescription,
    [MOVE_TEETER_DANCE - 1] = sTeeterDanceDescription,
    [MOVE_BLAZE_KICK - 1] = sBlazeKickDescription,
    [MOVE_MUD_SPORT - 1] = sMudSportDescription,
    [MOVE_ICE_BALL - 1] = sIceBallDescription,
    [MOVE_NEEDLE_ARM - 1] = sNeedleArmDescription,
    [MOVE_SLACK_OFF - 1] = sSlackOffDescription,
    [MOVE_HYPER_VOICE - 1] = sHyperVoiceDescription,
    [MOVE_POISON_FANG - 1] = sPoisonFangDescription,
    [MOVE_CRUSH_CLAW - 1] = sCrushClawDescription,
    [MOVE_BLAST_BURN - 1] = sBlastBurnDescription,
    [MOVE_HYDRO_CANNON - 1] = sHydroCannonDescription,
    [MOVE_METEOR_MASH - 1] = sMeteorMashDescription,
    [MOVE_ASTONISH - 1] = sAstonishDescription,
    [MOVE_WEATHER_BALL - 1] = sWeatherBallDescription,
    [MOVE_AROMATHERAPY - 1] = sAromatherapyDescription,
    [MOVE_FAKE_TEARS - 1] = sFakeTearsDescription,
    [MOVE_AIR_CUTTER - 1] = sAirCutterDescription,
    [MOVE_OVERHEAT - 1] = sOverheatDescription,
    [MOVE_ODOR_SLEUTH - 1] = sOdorSleuthDescription,
    [MOVE_ROCK_TOMB - 1] = sRockTombDescription,
    [MOVE_SILVER_WIND - 1] = sSilverWindDescription,
    [MOVE_METAL_SOUND - 1] = sMetalSoundDescription,
    [MOVE_GRASS_WHISTLE - 1] = sGrassWhistleDescription,
    [MOVE_TICKLE - 1] = sTickleDescription,
    [MOVE_COSMIC_POWER - 1] = sCosmicPowerDescription,
    [MOVE_WATER_SPOUT - 1] = sWaterSpoutDescription,
    [MOVE_SIGNAL_BEAM - 1] = sSignalBeamDescription,
    [MOVE_SHADOW_PUNCH - 1] = sShadowPunchDescription,
    [MOVE_EXTRASENSORY - 1] = sExtrasensoryDescription,
    [MOVE_SKY_UPPERCUT - 1] = sSkyUppercutDescription,
    [MOVE_SAND_TOMB - 1] = sSandTombDescription,
    [MOVE_SHEER_COLD - 1] = sSheerColdDescription,
    [MOVE_MUDDY_WATER - 1] = sMuddyWaterDescription,
    [MOVE_BULLET_SEED - 1] = sBulletSeedDescription,
    [MOVE_AERIAL_ACE - 1] = sAerialAceDescription,
    [MOVE_ICICLE_SPEAR - 1] = sIcicleSpearDescription,
    [MOVE_IRON_DEFENSE - 1] = sIronDefenseDescription,
    [MOVE_BLOCK - 1] = sBlockDescription,
    [MOVE_HOWL - 1] = sHowlDescription,
    [MOVE_DRAGON_CLAW - 1] = sDragonClawDescription,
    [MOVE_FRENZY_PLANT - 1] = sFrenzyPlantDescription,
    [MOVE_BULK_UP - 1] = sBulkUpDescription,
    [MOVE_BOUNCE - 1] = sBounceDescription,
    [MOVE_MUD_SHOT - 1] = sMudShotDescription,
    [MOVE_POISON_TAIL - 1] = sPoisonTailDescription,
    [MOVE_COVET - 1] = sCovetDescription,
    [MOVE_VOLT_TACKLE - 1] = sVoltTackleDescription,
    [MOVE_MAGICAL_LEAF - 1] = sMagicalLeafDescription,
    [MOVE_WATER_SPORT - 1] = sWaterSportDescription,
    [MOVE_CALM_MIND - 1] = sCalmMindDescription,
    [MOVE_LEAF_BLADE - 1] = sLeafBladeDescription,
    [MOVE_DRAGON_DANCE - 1] = sDragonDanceDescription,
    [MOVE_ROCK_BLAST - 1] = sRockBlastDescription,
    [MOVE_SHOCK_WAVE - 1] = sShockWaveDescription,
    [MOVE_WATER_PULSE - 1] = sWaterPulseDescription,
    [MOVE_DOOM_DESIRE - 1] = sDoomDesireDescription,
    [MOVE_PSYCHO_BOOST - 1] = sPsychoBoostDescription,
};
