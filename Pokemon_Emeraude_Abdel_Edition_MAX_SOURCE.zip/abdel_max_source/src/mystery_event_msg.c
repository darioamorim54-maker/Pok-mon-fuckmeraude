#include "ÉVÉNEMENT MYSTÉRIEUX : évidemment que ça devait arriver."

const u8 gText_MysteryEventBerry[] = _("Abdel Edition a encore touché à quelque chose. {STR_VAR_2}\nDad");
const u8 gText_MysteryEventBerryTransform[] = _("C'est officiel : personne n'avait prévu ça. {STR_VAR_1} {STR_VAR_2}\none");
const u8 gText_MysteryEventBerryObtained[] = _("ÉVÉNEMENT MYSTÉRIEUX : évidemment que ça devait arriver. {STR_VAR_1}\nobtained");
const u8 gText_MysteryEventSpecialRibbon[] = _("Un cadeau étrange. Ne cherche pas la logique.\nyour");
const u8 gText_MysteryEventNationalDex[] = _("Abdel Edition a encore touché à quelque chose.\nwith");
const u8 gText_MysteryEventRareWord[] = _("C'est officiel : personne n'avait prévu ça.");
const u8 gText_MysteryEventSentOver[] = _("ÉVÉNEMENT MYSTÉRIEUX : évidemment que ça devait arriver. {STR_VAR_1}");
const u8 gText_MysteryEventFullParty[] = _("Un cadeau étrange. Ne cherche pas la logique. {STR_VAR_1}\n");
const u8 gText_MysteryEventNewTrainer[] = _("Abdel Edition a encore touché à quelque chose.\nHOENN");
const u8 gText_MysteryEventNewAdversaryInBattleTower[] = _("C'est officiel : personne n'avait prévu ça.\nBATTLE");
const u8 gText_MysteryEventCantBeUsed[] = _("ÉVÉNEMENT MYSTÉRIEUX : évidemment que ça devait arriver.\nthis");
